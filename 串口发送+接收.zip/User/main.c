#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Serial.h"
#include <stdio.h>

char CenterStr[16];		//定义用于存放中心点字符串的数组

int main(void)
{
	/*模块初始化*/
	OLED_Init();		//OLED初始化
	Serial_Init();		//串口初始化
	
	/*显示静态字符串*/
	OLED_ShowString(1, 1, "Center(x,y):");
	
	while (1)
	{
		if (Serial_GetRxPacketFlag() == 1)		//检查串口接收一帧完成的标志位
		{
			sprintf(CenterStr, "%.0f,%.0f", Serial_GetRxX(), Serial_GetRxY());	//获取x,y并格式化为字符串
			OLED_ShowString(2, 1, CenterStr);	//显示串口接收的中心点坐标
		}
	}
}
