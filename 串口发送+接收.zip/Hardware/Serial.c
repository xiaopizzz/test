#include "stm32f10x.h"                  // Device header
#include <stdio.h>
#include <stdarg.h>

#define SERIAL_FRAME_HEAD		0xAA		//帧头
#define SERIAL_FRAME_TAIL		0xBB		//帧尾
#define SERIAL_RX_PACKET_LEN	8			//帧有效载荷长度：8字节，2个float（中心点x,y）

uint8_t Serial_RxPacket[SERIAL_RX_PACKET_LEN];	//接收到的整帧有效载荷
uint8_t Serial_RxPacketFlag;					//接收一帧完成的标志位
static uint8_t Serial_State;					//接收状态机：0找帧头 1收载荷 2等帧尾
static uint8_t Serial_RxCnt;					//已接收载荷字节计数

/**
  * 函    数：串口初始化
  * 参    数：无
  * 返 回 值：无
  */
void Serial_Init(void)
{
	/*开启时钟*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);	//开启USART1的时钟
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);	//开启GPIOA的时钟
	
	/*GPIO初始化*/
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);					//将PA9引脚初始化为复用推挽输出
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);					//将PA10引脚初始化为上拉输入
	
	/*USART初始化*/
	USART_InitTypeDef USART_InitStructure;					//定义结构体变量
	USART_InitStructure.USART_BaudRate = 115200;				//波特率
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;	//硬件流控制，不需要
	USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;	//模式，发送模式和接收模式均选择
	USART_InitStructure.USART_Parity = USART_Parity_No;		//奇偶校验，不需要
	USART_InitStructure.USART_StopBits = USART_StopBits_1;	//停止位，选择1位
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;		//字长，选择8位
	USART_Init(USART1, &USART_InitStructure);				//将结构体变量交给USART_Init，配置USART1
	
	/*中断输出配置*/
	USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);			//开启串口接收数据的中断
	
	/*NVIC中断分组*/
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);			//配置NVIC为分组2
	
	/*NVIC配置*/
	NVIC_InitTypeDef NVIC_InitStructure;					//定义结构体变量
	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;		//选择配置NVIC的USART1线
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			//指定NVIC线路使能
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;		//指定NVIC线路的抢占优先级为1
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;		//指定NVIC线路的响应优先级为1
	NVIC_Init(&NVIC_InitStructure);							//将结构体变量交给NVIC_Init，配置NVIC外设
	
	/*USART使能*/
	USART_Cmd(USART1, ENABLE);								//使能USART1，串口开始运行
}

/**
  * 函    数：串口发送一个字节
  * 参    数：Byte 要发送的一个字节
  * 返 回 值：无
  */
void Serial_SendByte(uint8_t Byte)
{
	USART_SendData(USART1, Byte);		//将字节数据写入数据寄存器，写入后USART自动生成时序波形
	while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);	//等待发送完成
	/*下次写入数据寄存器会自动清除发送完成标志位，故此循环后，无需清除标志位*/
}

/**
  * 函    数：串口发送一个数组
  * 参    数：Array 要发送数组的首地址
  * 参    数：Length 要发送数组的长度
  * 返 回 值：无
  */
void Serial_SendArray(uint8_t *Array, uint16_t Length)
{
	uint16_t i;
	for (i = 0; i < Length; i ++)		//遍历数组
	{
		Serial_SendByte(Array[i]);		//依次调用Serial_SendByte发送每个字节数据
	}
}

/**
  * 函    数：串口发送一个字符串
  * 参    数：String 要发送字符串的首地址
  * 返 回 值：无
  */
void Serial_SendString(char *String)
{
	uint8_t i;
	for (i = 0; String[i] != '\0'; i ++)//遍历字符数组（字符串），遇到字符串结束标志位后停止
	{
		Serial_SendByte(String[i]);		//依次调用Serial_SendByte发送每个字节数据
	}
}

/**
  * 函    数：次方函数（内部使用）
  * 返 回 值：返回值等于X的Y次方
  */
uint32_t Serial_Pow(uint32_t X, uint32_t Y)
{
	uint32_t Result = 1;	//设置结果初值为1
	while (Y --)			//执行Y次
	{
		Result *= X;		//将X累乘到结果
	}
	return Result;
}

/**
  * 函    数：串口发送数字
  * 参    数：Number 要发送的数字，范围：0~4294967295
  * 参    数：Length 要发送数字的长度，范围：0~10
  * 返 回 值：无
  */
void Serial_SendNumber(uint32_t Number, uint8_t Length)
{
	uint8_t i;
	for (i = 0; i < Length; i ++)		//根据数字长度遍历数字的每一位
	{
		Serial_SendByte(Number / Serial_Pow(10, Length - i - 1) % 10 + '0');	//依次调用Serial_SendByte发送每位数字
	}
}

/**
  * 函    数：使用printf需要重定向的底层函数
  * 参    数：保持原始格式即可，无需变动
  * 返 回 值：保持原始格式即可，无需变动
  */
int fputc(int ch, FILE *f)
{
	Serial_SendByte(ch);			//将printf的底层重定向到自己的发送字节函数
	return ch;
}

/**
  * 函    数：自己封装的prinf函数
  * 参    数：format 格式化字符串
  * 参    数：... 可变的参数列表
  * 返 回 值：无
  */
void Serial_Printf(char *format, ...)
{
	char String[100];				//定义字符数组
	va_list arg;					//定义可变参数列表数据类型的变量arg
	va_start(arg, format);			//从format开始，接收参数列表到arg变量
	vsprintf(String, format, arg);	//使用vsprintf打印格式化字符串和参数列表到字符数组中
	va_end(arg);					//结束变量arg
	Serial_SendString(String);		//串口发送字符数组（字符串）
}

/**
  * 函    数：获取串口接收一帧完成的标志位
  * 参    数：无
  * 返 回 值：接收一帧完成的标志位，范围：0~1，接收到完整一帧后，标志位置1，读取后标志位自动清零
  */
uint8_t Serial_GetRxPacketFlag(void)
{
	if (Serial_RxPacketFlag == 1)		//如果标志位为1
	{
		Serial_RxPacketFlag = 0;
		return 1;						//则返回1，并自动清零标志位
	}
	return 0;							//如果标志位为0，则返回0
}

/**
  * 函    数：解析 4 字节为一个 float（内部使用）
  * 参    数：Offset 在接收包中起始偏移，0 表示 x，4 表示 y
  * 返 回 值：解析出的 float 值
  */
static float Serial_ParseFloat(uint8_t Offset)
{
	union										//使用联合体，按内存顺序组合4字节为float
	{
		float f;
		uint8_t b[4];
	} value;

	value.b[0] = Serial_RxPacket[Offset + 0];	//低字节
	value.b[1] = Serial_RxPacket[Offset + 1];
	value.b[2] = Serial_RxPacket[Offset + 2];
	value.b[3] = Serial_RxPacket[Offset + 3];	//高字节

	return value.f;								//返回解析出的float
}

/**
  * 函    数：获取串口接收的中心点 x 坐标
  * 参    数：无
  * 返 回 值：解析出的 x，单位像素
  */
float Serial_GetRxX(void)
{
	return Serial_ParseFloat(0);				//取前4个字节解析为x
}

/**
  * 函    数：获取串口接收的中心点 y 坐标
  * 参    数：无
  * 返 回 值：解析出的 y，单位像素
  */
float Serial_GetRxY(void)
{
	return Serial_ParseFloat(4);				//取第5-8字节解析为y
}

/**
  * 函    数：USART1中断函数
  * 参    数：无
  * 返 回 值：无
  * 注意事项：此函数为中断函数，无需调用，中断触发后自动执行
  */
void USART1_IRQHandler(void)
{
	if (USART_GetITStatus(USART1, USART_IT_RXNE) == SET)		//判断是否是USART1的接收事件触发的中断
	{
		uint8_t RxData = USART_ReceiveData(USART1);				//读取数据寄存器，存放在接收的数据变量
		USART_ClearITPendingBit(USART1, USART_IT_RXNE);			//清除USART1的RXNE标志位

		switch (Serial_State)									//根据当前状态机状态处理接收的字节
		{
			case 0:												//找帧头状态
				if (RxData == SERIAL_FRAME_HEAD)				//如果收到帧头
				{
					Serial_RxCnt = 0;							//清空载荷计数
					Serial_State = 1;							//进入收载荷状态
				}
				break;
			case 1:												//收载荷状态
				Serial_RxPacket[Serial_RxCnt] = RxData;			//存放收到的载荷字节
				Serial_RxCnt ++;								//计数加1
				if (Serial_RxCnt == SERIAL_RX_PACKET_LEN)		//如果收满8字节
				{
					Serial_State = 2;							//进入等帧尾状态
				}
				break;
			case 2:												//等帧尾状态
				if (RxData == SERIAL_FRAME_TAIL)				//如果收到帧尾
				{
					Serial_RxPacketFlag = 1;					//置接收一帧完成的标志位
					Serial_State = 0;							//回到找帧头状态，准备接收下一帧
				}
				else if (RxData != SERIAL_FRAME_HEAD)			//如果既不是帧尾也不是帧头，说明数据错位
				{
					Serial_State = 0;							//回到找帧头状态，重新对齐
				}
				break;
		}
	}
}
